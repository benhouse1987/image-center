package com.example.imagefingerprint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageFingerprintApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImageFingerprintApplication.class, args);
	}

}
