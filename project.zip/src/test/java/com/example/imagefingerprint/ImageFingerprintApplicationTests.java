package com.example.imagefingerprint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageFingerprintApplicationTests {

	@Test
	void contextLoads() {
	}

}
